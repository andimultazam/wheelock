# import required package
import pandas as pd
from bs4 import BeautifulSoup
import re, unicodedata
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
import xgboost as xgb
from xgboost import XGBClassifier
import numpy as np
import nltk
from nltk.corpus import wordnet as wn
from nltk import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer

# Load training file.
print ("Loading train_v2.txt...");
train_file = pd.read_csv("data/train_v2.csv");
train_category = train_file.loc[:,'category'];
print ("Done loading train_v2.txt...");

# pre-processing - https://www.kdnuggets.com/2018/03/text-data-preprocessing-walkthrough-python.html
# remove html text
def strip_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()

def remove_between_square_brackets(text):
    return re.sub('\[[^]]*\]', '', text)

def denoise_text(text):
    text = strip_html(text)
    text = remove_between_square_brackets(text)
    return text

# normalization of text
def remove_non_ascii(words):
    """Remove non-ASCII characters from list of tokenized words"""
    new_words = []
    for word in words:
        new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
        new_words.append(new_word)
    return new_words

def to_lowercase(words):
    """Convert all characters to lowercase from list of tokenized words"""
    new_words = []
    for word in words:
        new_word = word.lower()
        new_words.append(new_word)
    return new_words

def remove_punctuation(words):
    """Remove punctuation from list of tokenized words"""
    new_words = []
    for word in words:
        new_word = re.sub(r'[^\w\s]', '', word)
        if new_word != '':
            new_words.append(new_word)
    return new_words

def normalize(words):
    words = remove_non_ascii(words)
    words = to_lowercase(words)
    words = remove_punctuation(words)
    return words

def lemmatize_verbs(words):
    """Lemmatize verbs in list of tokenized words"""
    lemmatizer = WordNetLemmatizer()
    lemmas = []
    for word in words:
        lemma = lemmatizer.lemmatize(word, pos='v')
        lemmas.append(lemma)
    return lemmas

# get the title and publisher columns and merge them
print ("Pre-processing train data...");
title_col = train_file.loc[:,'title'];
publisher_col = train_file.loc[:,'publisher'];
combined_str = ["" for i in range(len(title_col))];
    
for i in range(len(combined_str)):
    # combine the title and publisher string
    combined_str[i] = str(title_col[i]) + " " + str(publisher_col[i]);
    combined_str[i] = denoise_text(combined_str[i]);
    combined_str[i] = nltk.word_tokenize(combined_str[i]);
    combined_str[i] = normalize(combined_str[i]);
    combined_str[i] = lemmatize_verbs(combined_str[i])
    for j in range(len(combined_str[i])):
        if len(combined_str[i][j])<=2:
            combined_str[i][j] = "";
    tmp_str = combined_str[i][0];
    for x in range(1,len(combined_str[i])):
        tmp_str = tmp_str + " " + combined_str[i][x];
    combined_str[i] = tmp_str;


# count the words and use TFIDF to convert to values.
tcount_vect = CountVectorizer(token_pattern=r'\b[^\d\W]+\b') # exclude numbers
combined_str_counts = tcount_vect.fit_transform(combined_str)
ttfidf_transformer = TfidfTransformer()
title_train_tfidf = ttfidf_transformer.fit_transform(combined_str_counts)
print ("Done pre=processing train data...");

# train the training set using XGBClassifier
print ("Training data using XGBoostClassifier...");
clf = XGBClassifier(n_estimators=50, n_jobs=4,learning_rate=0.1,max_depth=10)
bst = clf.fit(title_train_tfidf.toarray(), train_category)
print ("Done training data...");

# Load test file
print ("Loading test_v2.txt...");
test_file = pd.read_csv('data/test_v2.csv');
test_title_col = test_file.loc[:,'title'];
test_publisher_col = test_file.loc[:,'publisher'];
print ("Done loading train_v2.txt...");
test_combined_str = ["" for i in range(len(test_title_col))];
# process the test file
print ("Pre-processing test data...");
for i in range(len(test_file)):
    # combine the title and publisher string
    test_combined_str[i] = str(test_title_col[i]) + " " + str(test_publisher_col[i]);
    test_combined_str[i] = denoise_text(test_combined_str[i]);
    test_combined_str[i] = nltk.word_tokenize(test_combined_str[i]);
    test_combined_str[i] = normalize(test_combined_str[i]);
    test_combined_str[i] = lemmatize_verbs(test_combined_str[i])
    tmp_str = test_combined_str[i][0];
    for x in range(1,len(test_combined_str[i])):
        tmp_str = tmp_str + " " + test_combined_str[i][x];
    test_combined_str[i] = tmp_str;

test_combined_str_counts = tcount_vect.transform(test_combined_str)
test_title_train_tfidf = ttfidf_transformer.transform(test_combined_str_counts)
print ("Done pre-processing test data...");

# predict the test values
print ("Predicting test data...");
predicted = clf.predict(test_title_train_tfidf.toarray())
print ("Done predicting test data...");

print ("Writing final submission file...");
f = open("Submission_XGBoost_nestimator50_depth10_lr0.1.csv",'w', encoding='utf-8');
f.write("article_id,category\n")
for i in range(len(test_file)):
    f.write(str(i+1) + "," +  str(int(predicted[i])) + "\n");

f.close()
print ("Done writing final submission file...");
print ("Complete!");