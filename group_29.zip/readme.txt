## Group 29 ##
## Members:
## - ANDI WAHYU MULTAZAM (e0338172@u.nus.edu)
## - HENG XIU TING (e0210456@u.nus.edu)
## - VALERIE HO TING-YI (e0267713@u.nus.edu)

## Version: python3.6.4
## Platform: Windows 10

#########################
## Files in the Folder ##
#########################
- requirements.txt : the packages that are required and used in the codes. (refer to install dependencies.)
- data/ : data folder, place the train_v2.txt and test_v2.txt inside this folder.
- readme.txt : this file.
- run.py : the main file to run the the classification (refer to run classification)

######################
## run.py structure ##
######################
# Pre-processing
1. Extract the 'title' and 'publiher' columns (which are more useful/informative)
2. For each row merge the 2 columns string together.
3. Denosie text
	i. remove any html strips
	ii. remove square brackets
4. Tokenize the string (each row)
5. normalize text
	i. remove any non-ascii characters
	ii. change all letters to lower case (consistent)
	iii. remove all punctuations
6. Lemmatize words using WordNetLemmatizer
7. merge the tokenized words back to string
8. Count each individual word using CountVectorizer()
9. Use TFIDFTransformer() to convert the string of words into values.
10. Use XGBoostClassifier to train the train set.
11. Use the test set, go through step 1 - 9.
12. Predict the output labels using the trained XGBoostClassifier() from step 10.

##########################
## Install dependencies ##
##########################
## TO install required package first before running the classification.
## 1. Navigatge to the folder group_29
## 2. Run the command below in command prompt for windows.
pip install -r requeriments.txt

########################
## Run classification ##
########################
# 1. Within the same folder group_29 run the following command in command prompt for windows.
python run.py

## output file: Submission_XGBoost_nestimator50_depth10_lr0.1.csv